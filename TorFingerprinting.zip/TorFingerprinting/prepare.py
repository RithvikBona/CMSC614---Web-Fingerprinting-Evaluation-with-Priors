"""Audit successful traces and hold out later collection days for evaluation."""
import argparse
import csv
import json
from collections import Counter
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

from common import (MANIFEST_FIELDS, REPRESENTATION, digest, label_matches, read_manifest,
                    read_trace, safe_path, successful_rows, write_json)


def audit(root):
    rows = successful_rows(read_manifest(root / 'manifest.csv'))
    if not rows:
        raise ValueError('Manifest has no collected traces')
    details = []
    for row in rows:
        path = safe_path(root, row['trace_file'])
        meta = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
        for field in ['domain', 'load_type', 'collected_at', 'requested_url', 'final_url']:
            if meta[field] != row[field]:
                raise ValueError(f'Manifest/sidecar mismatch for {field}: {path}')
        if meta['representation'] != REPRESENTATION or meta['trace_sha256'] != digest(path):
            raise ValueError(f'Representation/hash mismatch: {path}')
        if not meta['success'] or not meta.get('tor_verification', {}).get('is_tor'):
            raise ValueError(f'Successful trace lacks Tor verification: {path}')
        if not label_matches(row['domain'], row['final_url']):
            raise ValueError(f'Final domain mismatch: {path}')
        if meta.get('raw_file') and meta['raw_sha256'] != digest(safe_path(root, meta['raw_file'])):
            raise ValueError(f'Raw capture hash mismatch: {path}')
        times, directions = read_trace(path)
        if len(directions) != meta['packet_count'] or set(directions) != {-1, 1}:
            raise ValueError(f'Packet count/directions mismatch: {path}')
        details.append((row, meta, len(directions), times[-1]))
    return details


def grouped_split(details, timezone='America/New_York'):
    starts = {}
    for row, meta, *_ in details:
        run = datetime.fromisoformat(row['collected_at'].replace('Z', '+00:00')).astimezone(ZoneInfo(timezone)).date().isoformat()
        starts[run] = min(starts.get(run, row['collected_at']), row['collected_at'])
    runs = sorted(starts, key=starts.get)
    if len(runs) < 3:
        raise ValueError('Need at least 3 distinct collection days for train/validation/test. Same-day pilot is not a held-out evaluation.')
    ntrain = max(1, min(len(runs) - 2, round(0.70 * len(runs))))
    nval = max(1, min(len(runs) - ntrain - 1, round(0.15 * len(runs))))
    assigned = {run: 'train' if i < ntrain else 'validation' if i < ntrain + nval else 'test'
                for i, run in enumerate(runs)}
    splits = {name: [] for name in ['train', 'validation', 'test']}
    hashes = {}
    for row, meta, *_ in details:
        day = datetime.fromisoformat(row['collected_at'].replace('Z', '+00:00')).astimezone(ZoneInfo(timezone)).date().isoformat()
        name = assigned[day]
        trace_hash = meta['trace_sha256']
        if trace_hash in hashes and hashes[trace_hash] != name:
            raise ValueError('Identical trace content appears in multiple splits')
        hashes[trace_hash] = name
        splits[name].append(row)
    expected = {row['domain'] for row, *_ in details}
    if len(expected) < 2:
        raise ValueError('A classifier evaluation requires at least 2 monitored domains')
    expected_pairs = {(row['domain'], row['load_type']) for row, *_ in details}
    for name, rows in splits.items():
        missing = expected_pairs - {(r['domain'], r['load_type']) for r in rows}
        if missing:
            raise ValueError(f'{name} is missing domain/load_type pairs: {sorted(missing)}. Collect balanced runs.')
    return splits, assigned


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--audit-only', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()
    details = audit(root)
    counts = Counter((r['domain'], r['load_type']) for r, *_ in details)
    report = {'representation': REPRESENTATION, 'total_traces': len(details),
              'attempted_traces': len(read_manifest(root / 'manifest.csv')),
              'failed_traces': len(read_manifest(root / 'manifest.csv')) - len(details),
              'split_group': 'collection_day_America/New_York',
              'counts': [{'domain': d, 'load_type': k, 'count': n} for (d, k), n in sorted(counts.items())],
              'collection_runs': len({m['run_id'] for _, m, *_ in details}),
              'packet_count_min': min(n for _, _, n, _ in details),
              'packet_count_max': max(n for _, _, n, _ in details),
              'unmanifested_traces': sorted(p.relative_to(root).as_posix() for p in (root / 'traces').glob('*.trace')
                  if p.relative_to(root).as_posix() not in {r['trace_file'] for r in read_manifest(root / 'manifest.csv')})}
    (root / 'reports').mkdir(exist_ok=True)
    if not args.audit_only:
        splits, assigned = grouped_split(details)
        (root / 'splits').mkdir(exist_ok=True)
        for name, rows in splits.items():
            with (root / 'splits' / (name + '.csv')).open('w', newline='', encoding='utf-8') as stream:
                writer = csv.DictWriter(stream, fieldnames=MANIFEST_FIELDS)
                writer.writeheader()
                writer.writerows(rows)
        labels = sorted({r['domain'] for r, *_ in details})
        write_json(root / 'splits/labels.json', labels)
        write_json(root / 'splits/day_assignment.json', assigned)
        report['splits'] = {name: len(rows) for name, rows in splits.items()}
    write_json(root / 'reports/dataset_audit.json', report)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
