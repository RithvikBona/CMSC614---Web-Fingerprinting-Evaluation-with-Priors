# Tor trace collector and k-FP baseline

Working project: `C:\Users\ericw\Documents\School\TorFingerprinting`.

Use the existing Ubuntu WSL2 installation. The runtime is isolated at `/home/eric/tor-fingerprinting-runtime`, while source, data, and reports remain in this project folder. Native Windows is not supported by `tor-browser-selenium`.

## Current experiment

- `tor_monitored_50_domains.txt` is the user's ordered candidate list. Candidates have not all been validated through Tor.
- `config/domains.csv` contains all 50 domain labels and HTTPS root URLs.
- `config/pilot_domains.csv` contains `wikipedia.org`, `mozilla.org`, and `heise.de`.
- `pilot/` contains only the small pilot. `dataset/` is reserved for future full collection.
- The transferred `web_tracking_data.tar.gz` was located here and its raw browsing CSV schema verified. No browsing priors have been fitted.
- `baseline_kfp.py` implements forest leaf fingerprints and Hamming nearest-neighbor classification. It never loads `dirty-trained-kf.pkl`.

The active manifest contract is:

```csv
trace_file,domain,requested_url,final_url,collected_at,load_type,success
```

Every completed attempt gets a row, including failures. File paths are relative to the dataset root. Timestamps use UTC ISO 8601. `success` is `true` or `false`. Failed rows never enter model training. Domain labels remain the requested labels, redirects are recorded without silently changing them.

## Run on this computer

From PowerShell:

```powershell
wsl -d Ubuntu -- bash /mnt/c/Users/ericw/Documents/School/TorFingerprinting/run-wsl.sh collect.py --plan
wsl -d Ubuntu -- bash /mnt/c/Users/ericw/Documents/School/TorFingerprinting/run-wsl.sh collect.py --check
```

In Ubuntu, the shorter equivalent is:

```bash
cd /mnt/c/Users/ericw/Documents/School/TorFingerprinting
bash run-wsl.sh collect.py --plan
bash run-wsl.sh collect.py --check
```

The wrapper uses the project's Python 3.10 virtual environment and Tor-signed geckodriver. Ubuntu's preexisting default Python 3.12 has a pip/apt module mismatch. This project leaves the default interpreter alone. System packages installed for the collector include tshark, wireshark-common, browser libraries, and Python 3.10 venv support. Packet capture privileges are limited to the `dumpcap` executable, accessible to the `eric` Linux group. The browser and collector run as the ordinary Linux user.

Installed browser: Tor Browser 16.0.1, Firefox 153.7.0esr, bundled Tor 0.4.9.16, Tor-distributed geckodriver 0.37.0. Detached signatures for the browser and driver were verified against the Tor Browser Developers primary fingerprint `EF6E286DDA85EA2A4BA7DE684E2C6E8793298290`. The Python environment uses tbselenium 0.9.0 and Selenium 4.15.2. Newer Selenium 4.52 removed a FirefoxBinary module imported by tbselenium, so Selenium is pinned without downgrading Tor Browser. Full dependency versions and download checksums are saved in `reports/` and per-run logs.

## Pilot protocol

The default command targets two successful cold loads per pilot domain, collecting one load at a time:

```bash
bash run-wsl.sh collect.py --phase pilot --repeats 2 --batch-per-pair 2
```

There is a fixed 45-second observation window, a 15-second inter-attempt pause, and up to 5 seconds of extra jitter. The browser runs headlessly. A new copy of the Tor Browser template profile is used for each load. The browser first checks `https://check.torproject.org/api/ip`, requires `IsTor=true`, navigates to a blank page, and settles before capture. These verification requests are outside the capture window. The template profile must remain unused for browsing monitored sites.

`cold` means a fresh template profile for the monitored-page navigation. It does not mean an empty Tor cache or a new guard. With `--load-types cold warm`, each type is tracked separately. `warm` means an uncaptured prime of the same URL followed by a recorded second navigation within one browser instance. Only cold loads are used in the current pilot.

The collector owns a dedicated Tor process on localhost ports 9250 and 9251. It matches that process's established TCP socket tuples to the first-hop relay endpoints of built circuits. The BPF capture filter includes the full bidirectional local/remote IP and port tuples. Both guard connections are included when stock Tor uses multiple guards, for example Conflux. Capturing on WSL `eth0` excludes loopback SOCKS and control traffic. New external sockets during capture cause a conservative failure instead of accepting an incomplete trace.

`raw/<id>.pcapng` preserves the original encrypted packets. `traces/<id>.trace` stores seconds since navigation, direction (`+1` outgoing, `-1` incoming), and TCP payload bytes. Only payload-bearing TCP packets within the observation window enter the trace. Pure ACKs are omitted and retransmissions remain. These are observable packet traces, a TCP packet is not assumed to equal a Tor cell. Host segmentation/offloading and stock Tor maintenance or padding traffic can affect the representation, so keep the host, interface, and protocol consistent.

`traces/<id>.json` preserves the label, requested/final URLs, title, content-health summary, Tor check result, guard/circuit metadata, packet count, errors, checksums, and run ID. Screenshots and capture logs are stored in `logs/<run-id>/`. A same-domain redirect to `www` or a language path can succeed. A different final domain, challenge title, incomplete page, missing direction, packet loss, or a changed capture endpoint fails. A normal-looking title alone is not proof of normal content, inspect pilot screenshots before scaling.

## Validate pilot captures and extract k-FP features

```bash
bash run-wsl.sh review_pilot.py
bash run-wsl.sh prepare.py --root pilot --audit-only
bash run-wsl.sh baseline_kfp.py extract --root pilot
```

The independent raw-capture review requires every TCP packet to match a recorded socket of the dedicated Tor process, requires the remote peers to match recorded first-hop relays, checks hashes and zero capture drops, and re-extracts the trace from the pcap. It checks final domain labels and the Tor API proof. See `pilot/reports/pilot_validation.json` and `pilot/reports/kfp_features.npz`.

An interrupted process can leave an orphan raw capture and a stale lock. Preserve the orphan as an interrupted failure, never add it to successful training data. Confirm that the Linux PID in `.collection.lock` has exited before removing the stale lock and resuming. Resume counts only successful rows.

The current collector journals an in-progress sidecar before navigation. After confirming that a collector has exited and handling its stale lock, `bash run-wsl.sh recover_interrupted.py --root pilot` can finalize those journaled attempts as failures. The earliest interrupted pilot capture predates this journal and is listed separately in `unfinalized_raw_captures`, its missing metadata was not invented.

## Full collection, after reviewing the pilot

The full crawl has not started. Its command is provided for the next stage:

```bash
bash run-wsl.sh collect.py --phase full --repeats 100 --batch-per-pair 10
```

This targets 100 successful cold traces per candidate across repeated invocations, with at most 10 attempts per domain per invocation. Run batches at multiple times and on multiple days. This does not schedule future work automatically. Failures remain failures and do not count toward 100. Review the 50 candidates' accessibility before treating all as monitored classes. Do not replace inaccessible candidates or change labels silently.

Two load types with `--repeats 100` means 100 of each type, doubling the total. Choose that allocation before the full experiment. The pilot and full dataset are separate, so pilot tuning does not enter the held-out evaluation.

## Day-separated k-FP baseline

```bash
bash run-wsl.sh prepare.py --root dataset
bash run-wsl.sh baseline_kfp.py train --root dataset --trees 1000
bash run-wsl.sh baseline_kfp.py evaluate --root dataset
```

`prepare.py` uses successful rows only, checks label consistency and hashes, and groups by collection date in `America/New_York`. The earliest dates form training, the next dates validation, and the latest dates test. The target is roughly 70/15/15, actual counts depend on complete collection days. At least three distinct balanced collection days and two domains are required. Every domain/load-type pair must appear in each split. Same-day pilot runs cannot be turned into an evaluation by random splitting.

The feature extractor implements the author's 175-feature direction/timing layout. Three golden vectors match the author's reference implementation after only Python 3 syntax fixes. Sparse/zero-duration inputs receive defined finite values instead of the reference code's edge-case errors. Packet size is not used as a feature. This is a packet-trace adaptation for current Tor, not a claim to reproduce the original dataset or paper accuracy.

Training fits a random forest, saves each training instance's terminal leaf IDs, and uses nearest neighbors under the fraction of differing leaf IDs. This is not ordinary forest `predict_proba`. Neighbor-vote scores use additive smoothing. The neighbor count and a scalar temperature are chosen with validation data only. The saved `models/kfp.joblib` contains the forest, training leaf fingerprints, training labels/trace IDs, domain order, representation, feature version, class priors, calibration, and split hashes. It is trained only for this dataset's verified labels.

Evaluation exports top-1 accuracy, macro F1, confusion matrices, log loss, and per-domain score CSVs for validation and test. No valid held-out accuracy is available from a same-day pilot. Model serialization and leaf-neighbor prediction are tested using temporary synthetic fixtures, which never enter the real manifest.

## Browsing priors and HMM, later stage

See `EXPERIMENT_PROTOCOL.md`. The browsing-history data is a separate source, use its `domain` column because the `url` field is anonymized. Preserve consecutive same-domain visits. Split panelists before fitting population priors. Do not use the history CSV as Tor traffic or treat an unverified benchmark checkpoint's class IDs as this domain map.

## Tests and references

```bash
bash run-wsl.sh -m unittest discover -s tests -v
```

The tests cover manifest integrity, labeling, exact socket matching, directions, day-separated splits, reference feature parity, leaf-neighbor scores, calibration normalization, and forest/fingerprint serialization.

- [Tor Browser automation library](https://github.com/webfp/tor-browser-selenium)
- [Hayes and Danezis, k-fingerprinting, USENIX Security 2016](https://www.usenix.org/conference/usenixsecurity16/technical-sessions/presentation/hayes)
- [Author's k-FP implementation](https://github.com/jhayes14/k-FP)
- [Tor Research Safety Board guidelines](https://research.torproject.org/safetyboard/)
- [Tor-signed desktop artifacts](https://dist.torproject.org/torbrowser/16.0.1/)

The older `baseline_df.py` scaffold remains optional. The active baseline for this handoff is `baseline_kfp.py`.
