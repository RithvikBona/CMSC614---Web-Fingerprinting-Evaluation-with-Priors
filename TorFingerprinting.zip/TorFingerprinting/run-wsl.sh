#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PATH=/home/eric/tor-fingerprinting-runtime/bin:/home/eric/tor-fingerprinting-runtime/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
exec /home/eric/tor-fingerprinting-runtime/venv/bin/python "$@"
