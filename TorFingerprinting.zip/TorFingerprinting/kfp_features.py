"""Independent NumPy implementation of the k-FP author's 175-feature layout.

Reference: https://github.com/jhayes14/k-FP/blob/master/RF_fextract.py
Input is timing and direction, packet sizes are intentionally not features.
"""
import math
import numpy as np

FEATURE_VERSION = 'kfp_author_layout_175_packet_v1'


def chunks_by_fraction(sequence, count):
    # Retain the reference implementation's fractional slicing and extra chunk.
    if not len(sequence):
        return []
    step, start, result = len(sequence) / float(count), 0.0, []
    while start < len(sequence):
        result.append(sequence[int(start):int(start + step)])
        start += step
    return result


def features(times, directions):
    t, d = np.asarray(times, dtype=float), np.asarray(directions, dtype=int)
    if len(t) != len(d) or not len(t) or not np.isfinite(t).all() or np.any(np.diff(t) < 0):
        raise ValueError('Need nonempty, finite, time-ordered packets')
    if not np.isin(d, [-1, 1]).all():
        raise ValueError('Directions must be +/-1')
    t = t - t[0]
    incoming, outgoing = t[d == -1], t[d == 1]
    gaps = [np.diff(incoming), np.diff(outgoing), np.diff(t)]
    inter = [float(operation(g)) if len(g) else 0.0
             for operation in [np.max, np.mean, np.std, lambda a: np.percentile(a, 75)]
             for g in gaps]
    percentiles = [float(np.percentile(group, q)) if len(group) else 0.0
                   for group in [incoming, outgoing, t] for q in [25, 50, 75, 100]]
    counts = [len(incoming), len(outgoing), len(t)]
    edges = [int(np.sum(d[:30] == -1)), int(np.sum(d[:30] == 1)),
             int(np.sum(d[-30:] == -1)), int(np.sum(d[-30:] == 1))]
    concentration = [int(np.sum(d[start:start + 20] == 1)) for start in range(0, len(d), 20)]
    # Reference bins are [0,1], (1,2], ..., with an inclusive last timestamp.
    bins = max(1, math.ceil(float(t[-1])))
    cumulative = np.searchsorted(t, np.arange(1, bins + 1), side='right')
    per_second = np.diff(np.r_[0, cumulative]).tolist()
    out_positions, in_positions = np.flatnonzero(d == 1), np.flatnonzero(d == -1)
    def mean(values):
        return float(np.mean(values)) if len(values) else 0.0
    def std(values):
        return float(np.std(values)) if len(values) else 0.0
    scalars = [std(concentration), mean(concentration), mean(per_second), std(per_second),
               mean(out_positions), mean(in_positions), std(out_positions), std(in_positions),
               float(np.median(concentration)), float(np.median(per_second)), min(per_second),
               max(per_second), max(concentration), len(incoming) / len(t), len(outgoing) / len(t)]
    alternate_conc = [sum(part) for part in chunks_by_fraction(concentration, 70)]
    alternate_sec = [sum(part) for part in chunks_by_fraction(per_second, 20)]
    if len(alternate_conc) == 70:
        alternate_conc.append(0)
    if len(alternate_sec) == 20:
        alternate_sec.append(0)
    vector = inter + percentiles + counts + edges + scalars + alternate_conc + alternate_sec
    vector += [sum(alternate_conc), sum(alternate_sec), sum(inter), sum(percentiles), sum(counts)]
    vector += concentration + per_second
    vector = np.asarray((vector + [0] * 175)[:175], dtype=np.float64)
    if not np.isfinite(vector).all():
        raise ValueError('Nonfinite feature vector')
    return vector
