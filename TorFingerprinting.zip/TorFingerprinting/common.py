"""Dataset contracts shared by collection, splitting, and model code."""
import csv
import hashlib
import ipaddress
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

MANIFEST_FIELDS = ['trace_file', 'domain', 'requested_url', 'final_url', 'collected_at', 'load_type', 'success']
REPRESENTATION = 'tor_tcp_payload_packet_direction_v1'


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def append_csv(path, fields, row):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    exists = path.exists() and path.stat().st_size > 0
    if exists:
        with path.open(newline='', encoding='utf-8') as stream:
            if next(csv.reader(stream)) != fields:
                raise ValueError(f'Unexpected CSV header: {path}')
    with path.open('a', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        if not exists:
            writer.writeheader()
        writer.writerow(row)
        stream.flush()


def read_manifest(path):
    with Path(path).open(newline='', encoding='utf-8-sig') as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != MANIFEST_FIELDS:
            raise ValueError(f'Expected columns {MANIFEST_FIELDS}')
        rows = list(reader)
    if len({r['trace_file'] for r in rows}) != len(rows):
        raise ValueError('Duplicate trace_file rows')
    return rows


def label_matches(domain, url):
    host = (urlsplit(url).hostname or '').lower().rstrip('.')
    return host == domain or host.endswith('.' + domain)


def successful_rows(rows):
    return [row for row in rows if row['success'].lower() == 'true']


def read_domains(path):
    with Path(path).open(newline='', encoding='utf-8-sig') as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != ['domain', 'url']:
            raise ValueError('Domain CSV must have columns domain,url')
        rows = list(reader)
    seen = set()
    for row in rows:
        domain = row['domain'].strip().lower().rstrip('.').encode('idna').decode()
        url = row['url'].strip()
        parts = urlsplit(url)
        if (not domain or any(c in domain for c in '/:@ ') or
                parts.scheme not in ('http', 'https') or not parts.hostname or
                parts.username or parts.password):
            raise ValueError(f'Invalid domain/URL: {row}')
        host = parts.hostname.lower().rstrip('.').encode('idna').decode()
        if host != domain and not host.endswith('.' + domain):
            raise ValueError(f'URL hostname must equal domain or a subdomain: {row}')
        if domain in seen:
            raise ValueError(f'Duplicate domain: {domain}')
        seen.add(domain)
        row.update(domain=domain, url=url)
    if not rows:
        raise ValueError('No monitored domains supplied in domain CSV')
    return rows


def safe_path(root, relative):
    root = Path(root).resolve()
    candidate = (root / relative).resolve()
    if not candidate.is_relative_to(root):
        raise ValueError(f'Path escapes dataset root: {relative}')
    return candidate


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_trace(path):
    times, directions = [], []
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        fields = line.split()
        if len(fields) != 3:
            raise ValueError(f'Expected time, direction, payload bytes: {path}')
        t, direction, size = float(fields[0]), int(fields[1]), int(fields[2])
        if not math.isfinite(t) or t < 0 or direction not in (-1, 1) or size <= 0 or (times and t < times[-1]):
            raise ValueError(f'Invalid packet row: {path}')
        times.append(t)
        directions.append(direction)
    if not directions:
        raise ValueError(f'Empty trace: {path}')
    return times, directions


def make_bpf(sockets):
    clauses = []
    for local, lp, remote, rp in sorted(sockets):
        ipaddress.ip_address(local)
        ipaddress.ip_address(remote)
        clauses.append(f'((src host {local} and src port {int(lp)} and dst host {remote} and dst port {int(rp)}) or '
                       f'(src host {remote} and src port {int(rp)} and dst host {local} and dst port {int(lp)}))')
    if not clauses:
        raise ValueError('Tor has no established external TCP sockets')
    return 'tcp and (' + ' or '.join(clauses) + ')'


def decode_tshark(lines, sockets, started_at):
    """Only accept the exact Tor socket tuples recorded before capture."""
    result = []
    for line in lines:
        fields = line.rstrip('\r\n').split('\t')
        if len(fields) != 8:
            raise ValueError(f'Unexpected tshark field count: {len(fields)}')
        epoch, ip4s, ip6s, sp, ip4d, ip6d, dp, length = fields
        source, dest = ip4s or ip6s, ip4d or ip6d
        packet = (source, int(sp), dest, int(dp))
        reverse = (dest, int(dp), source, int(sp))
        direction = 1 if packet in sockets else -1 if reverse in sockets else 0
        elapsed = float(epoch) - started_at
        if direction and elapsed >= 0 and int(length) > 0:
            result.append((elapsed, direction, int(length)))
    return sorted(result, key=lambda r: r[0])
