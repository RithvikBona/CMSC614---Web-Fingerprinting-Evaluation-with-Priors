# Validated Tor pilot

Six usable cold traces were collected in the existing Ubuntu WSL2 environment, with a fixed 45-second window. The full 50-domain crawl has not started.

| Domain | Usable loads | Payload packets per trace | Final URL |
|---|---:|---|---|
| heise.de | 2 | 782, 751 | https://www.heise.de/ |
| mozilla.org | 2 | 283, 305 | https://www.mozilla.org/en-US/ |
| wikipedia.org | 2 | 119, 130 | https://www.wikipedia.org/ |

All six passed the browser Tor check, final-domain checks, zero-drop checks, file hashes, and an independent raw-packet check against owned Tor sockets and first-hop relay endpoints. The captures contain decoded TLS application-data records. Both first-hop connections were included.

The manifest has eight finalized attempts: six successes and two failures. One additional partial raw capture from an interrupted process is listed separately as unfinalized and excluded from labeled data. Its missing label record was not reconstructed.

Screenshots show Wikipedia and Mozilla landing pages. Heise shows its cookie-consent overlay over the homepage, no consent was selected. The pilot uses fresh profiles and headless rendering.

The six successful traces have a 6 x 175 k-FP feature matrix. Twenty-three tests passed, including reference feature parity and forest/leaf-fingerprint serialization. The split/train/calibrate/evaluate CLI also passed using temporary synthetic fixtures.

No production model accuracy is reported. All real pilot traces are from one local collection day, and the production splitter requires at least three distinct balanced days, with later days held out.

Installed combination: Tor Browser 16.0.1, Firefox 153.7.0esr, Tor 0.4.9.16, geckodriver 0.37.0, tbselenium 0.9.0, Selenium 4.15.2. Browser and driver signatures were verified against the Tor Browser Developers key.

Source project: C:\Users\ericw\Documents\School\TorFingerprinting. The original history archive remains there. The ZIP package excludes the large browsing-history archive and installed Linux runtime.

Automatic approval review rejected adding a reconstructed record for the interrupted capture, stating "blocked by policy". The raw capture remains unchanged and is documented separately.
