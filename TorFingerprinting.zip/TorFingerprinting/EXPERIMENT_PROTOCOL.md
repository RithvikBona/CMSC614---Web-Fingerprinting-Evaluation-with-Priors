# Experiment commitments

## Separate data sources

The located `web_tracking_data.tar.gz` contains `web_routineness_release/raw/browsing.csv`, with columns `web_visits_id,id,panelist_id,url,used_at,active_seconds,domain,subdomain`, and `raw/domain_categories.csv`. The browsing CSV supplies domain sequences, not traffic traces. Its anonymized URL identifiers are never crawl targets.

The user supplied 50 candidate domains. Their order and spelling are preserved in `tor_monitored_50_domains.txt`. The collector uses HTTPS root URLs from `config/domains.csv`. The list is a candidate set, not a claim that every site works normally through Tor.

## Browsing model, after the traffic baseline works

1. Assign panelists to deterministic training, validation, and test groups before fitting any priors. The population-only threat model is primary. No personal history from held-out panelists enters the population prior.
2. Sort each panelist's original visits by timestamp and a stable record key. Preserve consecutive same-domain visits, including self-transitions. Do not merge them away.
3. Fit population popularity and additively smoothed transition counts on training panelists only. Select smoothing and session-gap choices using validation panelists.
4. Choose and document how visits outside the monitored set are handled. Simply dropping them can create false adjacency between monitored sites, preserve an outside state or a session boundary instead.
5. Do not fit demographics, user identities, or priors from Tor traces. The current setup has not fitted a browsing prior.

## Traffic model

Collect only the project's own traffic, one load at a time, with pauses. Preserve all failed attempts and redirects. Use the fixed 45-second capture protocol, headless mode, recorded browser versions, and distinct cold/warm labels. Verify Tor use and first-hop capture endpoints. Keep the pilot separate from the full dataset.

Hold out later whole collection days. Fit the random forest and save training leaf fingerprints using training traces only. Choose k and score calibration using validation traces. Test traces never enter the forest, stored neighbors, hyperparameter selection, or calibration. Preserve the mapping between feature vectors, trace files, and domain labels. `dirty-trained-kf.pkl` is not used, its benchmark labels are not verified against these domains.

## Session pairing and comparisons

Pair held-out browsing visits with held-out Tor traces of exactly the same canonical domain. Training/validation/test trace pools remain disjoint. Record the random pairing seed and any trace reuse within a split. Report uncertainty in a way that accounts for repeated panelists, sessions, or reused traces.

Compare k-FP alone, k-FP plus popularity, and k-FP plus population transitions. The primary outcome is held-out per-visit top-1 accuracy. Use validation data to select fusion weights. Keep independent per-trace scores and domain order so the same test evidence is used in every comparison.

Calibrated classifier scores estimate posteriors under the training class distribution. For a generative HMM, use evidence proportional to the calibrated score divided by the training class prior, with numerical floors. Add the population transition prior and an explicitly documented initial-state distribution. Do not double-count the classifier's training prior.

For the shuffled-order control, permute held-out visits within each chosen session while keeping each visit's domain and paired trace/score together. This preserves popularity and per-trace evidence while disrupting visit order. Do not shuffle only the labels or only the scores. Keep the transition model fixed from the original training sequences.

These are later experiment stages. No full crawl, panelist split, fitted browsing prior, HMM, or production held-out accuracy has been created during the pilot setup.
