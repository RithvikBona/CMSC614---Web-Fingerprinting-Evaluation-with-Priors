"""Train/reload a DF architecture baseline on this project's packet representation.

Architecture follows Sirinam et al. (CCS 2018), implemented with PyTorch.
This is a modern reimplementation, not the authors' original trained checkpoint.
"""
import argparse
import csv
import json
import math
import random
from pathlib import Path

from common import REPRESENTATION, digest, read_manifest, read_trace, safe_path, write_json


def build_model(classes, length=5000):
    import torch
    from torch import nn
    from torch.nn import functional as F

    class SamePool(nn.Module):
        def forward(self, x):
            padding = max(0, (math.ceil(x.shape[-1] / 4) - 1) * 4 + 8 - x.shape[-1])
            return F.max_pool1d(F.pad(x, (padding // 2, padding - padding // 2), value=-float('inf')), 8, 4)

    layers = []
    channels = 1
    size = length
    for block, width in enumerate([32, 64, 128, 256]):
        for _ in range(2):
            layers.extend([nn.Conv1d(channels, width, 8, padding='same'),
                           nn.BatchNorm1d(width, eps=1e-3, momentum=0.01),
                           nn.ELU() if block == 0 else nn.ReLU()])
            channels = width
        layers.extend([SamePool(), nn.Dropout(0.1)])
        size = math.ceil(size / 4)
    layers.extend([nn.Flatten(), nn.Linear(channels * size, 512),
                   nn.BatchNorm1d(512, eps=1e-3, momentum=0.01), nn.ReLU(), nn.Dropout(0.7),
                   nn.Linear(512, 512), nn.BatchNorm1d(512, eps=1e-3, momentum=0.01),
                   nn.ReLU(), nn.Dropout(0.5), nn.Linear(512, classes)])
    model = nn.Sequential(*layers)
    for module in model.modules():
        if isinstance(module, (nn.Conv1d, nn.Linear)):
            nn.init.xavier_uniform_(module.weight)
            nn.init.zeros_(module.bias)
    return model


def load_data(root, manifest, labels, length):
    import numpy as np
    import torch
    from torch.utils.data import TensorDataset
    rows = read_manifest(manifest)
    if not rows:
        raise ValueError(f'Empty split: {manifest}')
    x = np.zeros((len(rows), 1, length), dtype=np.float32)
    y = np.empty(len(rows), dtype=np.int64)
    mapping = {label: i for i, label in enumerate(labels)}
    for i, row in enumerate(rows):
        path = safe_path(root, row['trace_file'])
        meta = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
        if meta['representation'] != REPRESENTATION or meta['trace_sha256'] != digest(path):
            raise ValueError(f'Invalid trace/representation: {path}')
        if any(meta[key] != row[key] for key in ['domain', 'collected_at', 'load_type']):
            raise ValueError(f'Manifest label mismatch: {path}')
        _, directions = read_trace(path)
        n = min(length, len(directions))
        x[i, 0, :n] = directions[:n]
        y[i] = mapping[row['domain']]
    return rows, TensorDataset(torch.from_numpy(x), torch.from_numpy(y))


def predict(model, data, device, batch_size):
    import numpy as np
    import torch
    from torch.utils.data import DataLoader
    model.eval()
    outputs = []
    with torch.no_grad():
        for x, _ in DataLoader(data, batch_size=batch_size, shuffle=False):
            outputs.append(model(x.to(device)).softmax(dim=1).cpu().numpy())
    return np.concatenate(outputs)


def save_scores(path, rows, probabilities, labels):
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream)
        writer.writerow(['trace_file', 'domain', 'load_type', 'predicted_domain'] + ['p:' + d for d in labels])
        for row, scores in zip(rows, probabilities):
            writer.writerow([row['trace_file'], row['domain'], row['load_type'], labels[int(scores.argmax())]] +
                            [f'{float(p):.9g}' for p in scores])


def evaluation(probabilities, data, rows, labels):
    import numpy as np
    y = data.tensors[1].numpy()
    predicted = probabilities.argmax(axis=1)
    confusion = np.zeros((len(labels), len(labels)), dtype=int)
    for a, b in zip(y, predicted):
        confusion[a, b] += 1
    recall = np.diag(confusion) / np.maximum(1, confusion.sum(axis=1))
    precision = np.diag(confusion) / np.maximum(1, confusion.sum(axis=0))
    f1 = 2 * precision * recall / np.maximum(1e-12, precision + recall)
    by_type = {}
    for kind in sorted({r['load_type'] for r in rows}):
        mask = np.array([r['load_type'] == kind for r in rows])
        by_type[kind] = {'n': int(mask.sum()), 'top1_accuracy': float((predicted[mask] == y[mask]).mean())}
    return {'n': len(y), 'top1_accuracy': float((predicted == y).mean()),
            'macro_f1': float(f1.mean()), 'labels': labels, 'confusion_matrix': confusion.tolist(),
            'by_load_type': by_type, 'probabilities_calibrated': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['train', 'evaluate'])
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--checkpoint', type=Path)
    parser.add_argument('--epochs', type=int, default=30)
    parser.add_argument('--batch-size', type=int, default=128)
    parser.add_argument('--learning-rate', type=float, default=0.002)
    parser.add_argument('--seed', type=int, default=614)
    parser.add_argument('--device', default='auto', choices=['auto', 'cpu', 'cuda'])
    parser.add_argument('--length', type=int, default=5000)
    args = parser.parse_args()
    if args.batch_size < 2 or args.epochs < 1 or args.length < 1 or args.learning_rate <= 0:
        parser.error('Batch size must be >=2, epochs/length/learning rate must be positive')
    import numpy as np
    import torch
    from torch.utils.data import DataLoader
    root = args.root.resolve()
    checkpoint = (args.checkpoint or root / 'models/df_packet.pt').resolve()
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    (root / 'reports').mkdir(exist_ok=True)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device('cuda' if args.device == 'auto' and torch.cuda.is_available() else
                          'cpu' if args.device == 'auto' else args.device)
    if args.mode == 'train':
        from prepare import audit, grouped_split
        # Re-audit current data and require manifests to match the grouped split.
        expected, _ = grouped_split(audit(root))
        for name, rows in expected.items():
            if read_manifest(root / 'splits' / (name + '.csv')) != rows:
                raise ValueError('Stale or altered splits. Run prepare.py again.')
        labels = json.loads((root / 'splits/labels.json').read_text(encoding='utf-8'))
        if labels != sorted({r['domain'] for r in expected['train']}):
            raise ValueError('Label map does not match training domains')
        train_rows, train = load_data(root, root / 'splits/train.csv', labels, args.length)
        validation_rows, validation = load_data(root, root / 'splits/validation.csv', labels, args.length)
        if len(train) < 2:
            raise ValueError('Need at least 2 training traces')
        model = build_model(len(labels), args.length).to(device)
        training_class_prior = (np.bincount(train.tensors[1].numpy(), minlength=len(labels)) / len(train)).tolist()
        write_json(root / 'reports/training_class_prior.json', dict(zip(labels, training_class_prior)))
        optimizer = torch.optim.Adamax(model.parameters(), lr=args.learning_rate)
        loader = DataLoader(train, batch_size=min(args.batch_size, len(train)), shuffle=True,
                            drop_last=len(train) % min(args.batch_size, len(train)) == 1)
        best, history = float('inf'), []
        for epoch in range(args.epochs):
            model.train()
            losses = []
            for x, y in loader:
                optimizer.zero_grad()
                loss = torch.nn.functional.cross_entropy(model(x.to(device)), y.to(device))
                loss.backward()
                optimizer.step()
                losses.append(float(loss.detach().cpu()))
            probs = predict(model, validation, device, args.batch_size)
            yv = validation.tensors[1].numpy()
            nll = float(-np.log(np.maximum(1e-12, probs[np.arange(len(yv)), yv])).mean())
            record = {'epoch': epoch + 1, 'train_loss': float(np.mean(losses)),
                      'validation_nll': nll, 'validation_accuracy': float((probs.argmax(1) == yv).mean())}
            history.append(record)
            print(json.dumps(record), flush=True)
            if nll < best:
                best = nll
                torch.save({'state_dict': model.state_dict(), 'labels': labels, 'length': args.length,
                            'representation': REPRESENTATION, 'architecture': 'DF_PyTorch_reimplementation_v1',
                            'seed': args.seed, 'best_epoch': epoch + 1, 'torch_version': str(torch.__version__),
                            'training_class_prior': training_class_prior,
                            'split_hashes': {name: digest(root / 'splits' / (name + '.csv'))
                                             for name in ['train', 'validation', 'test']}}, checkpoint)
        write_json(root / 'reports/training_history.json', history)
        print('Saved best validation checkpoint. Run evaluate once for held-out test metrics.')
        return
    saved = torch.load(checkpoint, map_location=device, weights_only=True)
    if saved['representation'] != REPRESENTATION:
        raise ValueError('Checkpoint input representation does not match these traces')
    labels, length = saved['labels'], saved['length']
    for name, expected_hash in saved['split_hashes'].items():
        if digest(root / 'splits' / (name + '.csv')) != expected_hash:
            raise ValueError('Split files changed since training, retrain or restore the original dataset')
    model = build_model(len(labels), length).to(device)
    model.load_state_dict(saved['state_dict'])
    for name in ['validation', 'test']:
        rows, data = load_data(root, root / 'splits' / (name + '.csv'), labels, length)
        probs = predict(model, data, device, args.batch_size)
        save_scores(root / 'reports' / ('df_' + name + '_scores.csv'), rows, probs, labels)
        report = evaluation(probs, data, rows, labels)
        report.update(checkpoint_sha256=digest(checkpoint), representation=REPRESENTATION)
        write_json(root / 'reports' / ('df_' + name + '_metrics.json'), report)
        print(name + ': ' + json.dumps(report))


if __name__ == '__main__':
    main()
