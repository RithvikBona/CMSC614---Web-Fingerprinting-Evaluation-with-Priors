import json
import sys
import tempfile
import unittest
from pathlib import Path
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from baseline_kfp import calibrate, leaf_scores
from kfp_features import features


class KFPTests(unittest.TestCase):
    def test_author_reference_feature_vectors(self):
        fixture = json.loads((Path(__file__).parent / 'fixtures/kfp_reference_vectors.json').read_text())
        for case in fixture['cases']:
            np.testing.assert_allclose(features(case['times'], case['directions']), case['expected'], rtol=1e-10, atol=1e-10)

    def test_direction_timing_input_validation(self):
        for times, directions in [([], []), ([1, 0], [1, -1]), ([0, 1], [1, 0]), ([0, float('nan')], [1, -1])]:
            with self.assertRaises(ValueError):
                features(times, directions)
        self.assertEqual(features([0], [1]).shape, (175,))

    def test_leaf_hamming_knn_votes_and_smoothing(self):
        training = np.array([[1, 2, 3], [1, 2, 4], [8, 9, 0]])
        y = np.array([0, 0, 1])
        scores = leaf_scores(np.array([[1, 2, 3], [8, 9, 0]]), training, y, 2, k=1)
        self.assertEqual(scores.argmax(1).tolist(), [0, 1])
        np.testing.assert_allclose(scores.sum(axis=1), 1)
        self.assertTrue((scores > 0).all())

    def test_temperature_preserves_top1_and_normalization(self):
        scores = np.array([[0.8, 0.15, 0.05], [0.1, 0.3, 0.6]])
        adjusted = calibrate(scores, 2.5)
        self.assertEqual(scores.argmax(1).tolist(), adjusted.argmax(1).tolist())
        np.testing.assert_allclose(adjusted.sum(1), 1)

    def test_forest_and_training_leaf_roundtrip(self):
        rng = np.random.default_rng(614)
        x = np.r_[rng.normal(-2, 0.1, (12, 175)), rng.normal(2, 0.1, (12, 175))]
        y = np.r_[np.zeros(12, dtype=int), np.ones(12, dtype=int)]
        forest = RandomForestClassifier(n_estimators=32, random_state=614).fit(x, y)
        leaves = forest.apply(x).astype(np.int32)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'model.joblib'
            joblib.dump(dict(forest=forest, training_leaves=leaves, training_y=y), path)
            state = joblib.load(path)
            query = state['forest'].apply(np.array([x[0] + 0.01, x[-1] - 0.01]))
            scores = leaf_scores(query, state['training_leaves'], state['training_y'], 2, k=3)
            self.assertEqual(scores.argmax(1).tolist(), [0, 1])


if __name__ == '__main__':
    unittest.main()
