import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import (MANIFEST_FIELDS, REPRESENTATION, append_csv, decode_tshark,
                    digest, label_matches, make_bpf, read_domains, read_manifest, read_trace,
                    safe_path, write_json)
from collect import dataset_lock, reported_drops
from prepare import audit, grouped_split
from recover_interrupted import recover


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_manifest_header_and_round_trip(self):
        row = dict(trace_file='traces/a.trace', domain='example.com',
                   requested_url='https://example.com/', final_url='https://www.example.com/',
                   collected_at='2026-11-16T01:00:00Z', load_type='cold', success='true')
        path = self.root / 'manifest.csv'
        append_csv(path, MANIFEST_FIELDS, row)
        self.assertEqual(read_manifest(path), [row])
        self.assertEqual(path.read_text().splitlines()[0], ','.join(MANIFEST_FIELDS))

    def test_duplicate_manifest_rejected(self):
        path = self.root / 'manifest.csv'
        row = dict.fromkeys(MANIFEST_FIELDS, 'duplicate')
        append_csv(path, MANIFEST_FIELDS, row)
        append_csv(path, MANIFEST_FIELDS, row)
        with self.assertRaisesRegex(ValueError, 'Duplicate'):
            read_manifest(path)

    def test_manifest_wrong_header_rejected_before_append(self):
        path = self.root / 'manifest.csv'
        path.write_text('wrong,columns\n')
        with self.assertRaisesRegex(ValueError, 'header'):
            append_csv(path, MANIFEST_FIELDS, {})
        self.assertEqual(path.read_text(), 'wrong,columns\n')

    def test_domains_normalize_and_validate(self):
        path = self.root / 'domains.csv'
        path.write_text('domain,url\nEXAMPLE.COM.,https://www.example.com/\n')
        self.assertEqual(read_domains(path)[0]['domain'], 'example.com')
        path.write_text('domain,url\nexample.com,https://unrelated.org/\n')
        with self.assertRaises(ValueError):
            read_domains(path)
        path.write_text('domain,url\n')
        with self.assertRaisesRegex(ValueError, 'No monitored'):
            read_domains(path)

    def test_path_escape_rejected(self):
        with self.assertRaises(ValueError):
            safe_path(self.root, '../outside.trace')

    def test_decode_ipv4_ipv6_and_ignore_other_connections(self):
        sockets = {('10.0.0.2', 50001, '1.2.3.4', 443), ('2001:db8::1', 50002, '2001:db8::2', 9001)}
        lines = ['100.1\t10.0.0.2\t\t50001\t1.2.3.4\t\t443\t512',
                 '100.2\t1.2.3.4\t\t443\t10.0.0.2\t\t50001\t1024',
                 '100.3\t\t2001:db8::2\t9001\t\t2001:db8::1\t50002\t300',
                 '100.4\t10.0.0.2\t\t59999\t1.2.3.4\t\t443\t123',
                 '99.0\t10.0.0.2\t\t50001\t1.2.3.4\t\t443\t512']
        result = decode_tshark(lines, sockets, 100.0)
        self.assertEqual([r[1] for r in result], [1, -1, -1])
        self.assertEqual([r[2] for r in result], [512, 1024, 300])
        self.assertAlmostEqual(result[0][0], 0.1)

    def test_bpf_requires_exact_local_and_remote_ports(self):
        bpf = make_bpf({('10.0.0.2', 50001, '1.2.3.4', 443)})
        self.assertIn('src port 50001', bpf)
        self.assertIn('dst port 50001', bpf)
        self.assertIn('dst host 1.2.3.4', bpf)
        with self.assertRaises(ValueError):
            make_bpf(set())
        with self.assertRaises(ValueError):
            make_bpf({('invalid string', 1, '1.2.3.4', 443)})

    def test_trace_rejects_zero_direction_and_time_reversal(self):
        path = self.root / 'bad.trace'
        for text in ['0\t0\t512\n', '1\t1\t512\n0\t-1\t512\n', '0\t1\t0\n', 'nan\t1\t512\n', '']:
            path.write_text(text)
            with self.assertRaises(ValueError):
                read_trace(path)

    def test_dumpcap_drop_statistics(self):
        self.assertEqual(reported_drops("Packets received/dropped on interface 'any': 123/0 (pcap:0/dumpcap:0)"), 0)
        self.assertEqual(reported_drops("Packets received/dropped on interface 'any': 123/5 (pcap:5/dumpcap:0)"), 5)
        self.assertEqual(reported_drops('Packets dropped: 2'), 2)
        self.assertIsNone(reported_drops('No statistics were produced'))

    def test_collection_lock_excludes_second_writer(self):
        with dataset_lock(self.root):
            with self.assertRaises(FileExistsError):
                with dataset_lock(self.root):
                    self.fail('Concurrent collector acquired lock')
        self.assertFalse((self.root / '.collection.lock').exists())

    def fixture(self, nruns=10):
        (self.root / 'traces').mkdir()
        for run in range(nruns):
            for label in ['example.com', 'example.org']:
                file = self.root / 'traces' / f'{run}_{label}.trace'
                file.write_text(f'# synthetic unit-test fixture only\n0.01\t1\t512\n{run + 0.2:.3f}\t-1\t1024\n')
                row = dict(trace_file=file.relative_to(self.root).as_posix(), domain=label,
                           requested_url='https://' + label + '/', final_url='https://' + label + '/',
                           collected_at=f'2026-11-{run + 1:02d}T12:00:00Z', load_type='cold', success='true')
                meta = dict(row, representation=REPRESENTATION, run_id=f'run{run:02d}',
                            packet_count=2, trace_sha256=digest(file), tor_verification={'is_tor': True})
                meta['success'] = True
                write_json(file.with_suffix('.json'), meta)
                append_csv(self.root / 'manifest.csv', MANIFEST_FIELDS, row)
        return audit(self.root)

    def test_audit_and_grouped_chronological_split(self):
        details = self.fixture()
        splits, assignment = grouped_split(details)
        self.assertEqual([len(splits[name]) for name in ['train', 'validation', 'test']], [14, 4, 2])
        self.assertEqual(assignment['2026-11-01'], 'train')
        self.assertEqual(assignment['2026-11-10'], 'test')
        sets = [set(r['trace_file'] for r in rows) for rows in splits.values()]
        self.assertTrue(sets[0].isdisjoint(sets[1]) and sets[1].isdisjoint(sets[2]))

    def test_split_rejects_too_few_runs(self):
        with self.assertRaisesRegex(ValueError, 'at least 3'):
            grouped_split(self.fixture(nruns=2))

    def test_audit_rejects_changed_trace(self):
        self.fixture(nruns=3)
        next((self.root / 'traces').glob('*.trace')).write_text('0\t1\t512\n')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            audit(self.root)

    def test_audit_rejects_wrong_domain_label(self):
        self.fixture(nruns=3)
        path = next((self.root / 'traces').glob('*.json'))
        meta = json.loads(path.read_text())
        meta['domain'] = 'wrong.org'
        write_json(path, meta)
        with self.assertRaisesRegex(ValueError, 'mismatch for domain'):
            audit(self.root)

    def test_split_rejects_missing_domain_in_test(self):
        details = self.fixture(nruns=3)
        details = [item for item in details if not (item[1]['run_id'] == 'run02' and item[0]['domain'] == 'example.org')]
        with self.assertRaisesRegex(ValueError, 'missing domain/load_type'):
            grouped_split(details)

    def test_final_label_requires_domain_boundary(self):
        self.assertTrue(label_matches('mozilla.org', 'https://www.mozilla.org/en-US/'))
        self.assertFalse(label_matches('mozilla.org', 'https://notmozilla.org/'))
        self.assertFalse(label_matches('mozilla.org', 'https://mozilla.org.evil.example/'))

    def test_same_day_runs_cannot_form_evaluation(self):
        details = self.fixture(nruns=3)
        for row, _, *_ in details:
            row['collected_at'] = '2026-11-16T12:00:00Z'
        with self.assertRaisesRegex(ValueError, 'distinct collection days'):
            grouped_split(details)

    def test_interrupted_attempt_recovery_is_failure_and_idempotent(self):
        self.fixture(nruns=3)
        trace = self.root / 'traces/pending.trace'
        trace.write_text('# no complete timing conversion\n')
        (self.root / 'raw').mkdir()
        raw = self.root / 'raw/pending.pcapng'
        raw.write_bytes(b'unchanged raw capture fixture')
        before = digest(raw)
        write_json(trace.with_suffix('.json'), dict(trace_id='pending', domain='example.com',
            requested_url='https://example.com/', final_url='', collected_at='2026-11-16T12:00:00Z',
            load_type='cold', collection_state='in_progress', success=False))
        self.assertEqual(recover(self.root), ['traces/pending.trace'])
        self.assertEqual(read_manifest(self.root / 'manifest.csv')[-1]['success'], 'false')
        self.assertEqual(digest(raw), before)
        self.assertEqual(recover(self.root), [])


if __name__ == '__main__':
    unittest.main()
