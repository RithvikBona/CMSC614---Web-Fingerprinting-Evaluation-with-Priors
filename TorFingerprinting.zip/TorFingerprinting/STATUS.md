# Validated pilot, full crawl stopped

The project is working in Ubuntu WSL2 on this Windows 11 computer. Six successful cold traces were collected and independently checked, two each for wikipedia.org, mozilla.org, and heise.de. The pilot manifest also contains two finalized failures. One interrupted raw capture is retained separately as unfinalized, with no inferred label record added.

The pilot uses 45-second observation windows and records the seven requested manifest columns. Successful captures passed Tor API verification, final-domain matching, checksum checks, zero capture drops, and independent verification that every raw TCP packet belongs to recorded Tor process sockets connected to first-hop relays. TLS application-data decoding is recorded in the validation report. Both first-hop connections are captured under the stock Tor configuration.

Screenshots of Wikipedia and Mozilla show their landing pages. Heise shows its cookie-consent overlay over the homepage. No consent choice was made. These are unconsented fresh-profile traces, keep that condition in the collection protocol.

The six usable traces have been converted to 175 k-FP direction/timing features each. Twenty-three tests pass, including parity with three author-reference feature vectors and forest/fingerprint serialization. A synthetic end-to-end CLI check exercised split creation, model fitting, checkpoint saving, validation calibration, and evaluation without touching the real data.

No production k-FP checkpoint or meaningful held-out accuracy is available yet. All pilot traces were collected on one local calendar day. Training/evaluation requires balanced collection over at least three distinct days, with later dates held out. No full crawl has started, no browsing prior has been fitted, and no HMM experiment has been run.

Next stage after pilot review: validate the remaining domain candidates through Tor, then collect repeated full-dataset batches across days. The 50-domain list is preserved in tor_monitored_50_domains.txt. The history archive is present and its raw browsing CSV header was verified, its anonymized URL field is never a crawl target.

See pilot/reports/pilot_validation.json, pilot/manifest.csv, pilot/reports/kfp_features.npz, README.md, and EXPERIMENT_PROTOCOL.md.
