"""Independently check raw pilot captures against process sockets and guard metadata."""
import argparse
import json
import subprocess
from collections import Counter
from pathlib import Path
import numpy as np

from common import digest, label_matches, read_manifest, read_trace, safe_path, successful_rows, write_json
from collect import extract


def review(root):
    rows = read_manifest(root / 'manifest.csv')
    details = []
    for row in successful_rows(rows):
        path = safe_path(root, row['trace_file'])
        meta = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
        pcap = safe_path(root, meta['raw_file'])
        connections = {tuple(c) for c in meta['tor_sockets']}
        endpoints = {tuple(endpoint) for relay in meta['first_hop_relays'] for endpoint in relay['endpoints']}
        assert all((c[2], c[3]) in endpoints for c in connections), 'Non-guard capture endpoint'
        assert meta['tor_verification']['is_tor'] is True, 'Missing Tor API proof'
        assert label_matches(row['domain'], row['final_url']), 'Wrong final domain'
        assert digest(path) == meta['trace_sha256'] and digest(pcap) == meta['raw_sha256'], 'Checksum changed'
        fields = ['ip.src', 'ipv6.src', 'tcp.srcport', 'ip.dst', 'ipv6.dst', 'tcp.dstport', 'tcp.len']
        command = ['tshark', '-n', '-r', str(pcap), '-Y', 'tcp', '-T', 'fields', '-E', 'separator=/t', '-E', 'occurrence=f']
        for field in fields:
            command.extend(['-e', field])
        decoded = subprocess.run(command, capture_output=True, text=True, check=True, timeout=120).stdout.splitlines()
        unknown = []
        for line in decoded:
            s4, s6, sp, d4, d6, dp, length = line.split('\t')
            pair = (s4 or s6, int(sp), d4 or d6, int(dp))
            reverse = (d4 or d6, int(dp), s4 or s6, int(sp))
            if pair not in connections and reverse not in connections:
                unknown.append(pair)
        assert not unknown, 'Raw capture contains a socket outside this Tor process'
        packets = extract(pcap, connections, meta['capture_started_epoch'], meta['window_seconds'])
        times, directions = read_trace(path)
        np.testing.assert_allclose(times, [packet[0] for packet in packets], atol=0.000001, rtol=0)
        assert directions == [packet[1] for packet in packets], 'Direction mismatch'
        assert len(packets) == meta['packet_count'] and meta['reported_dropped_packets'] == 0
        tls_command = ['tshark', '-n', '-r', str(pcap)]
        for port in sorted({connection[3] for connection in connections}):
            tls_command.extend(['-d', f'tcp.port=={port},tls'])
        tls_command.extend(['-Y', 'tls.record.content_type == 23', '-T', 'fields', '-e', 'frame.number'])
        tls_result = subprocess.run(tls_command, capture_output=True, text=True, check=True, timeout=120)
        details.append(dict(trace_file=row['trace_file'], domain=row['domain'], requested_url=row['requested_url'],
            final_url=row['final_url'], collected_at=row['collected_at'], load_type=row['load_type'],
            payload_packets=len(packets), raw_tcp_packets=len(decoded), raw_bytes=pcap.stat().st_size,
            outgoing_packets=directions.count(1), incoming_packets=directions.count(-1),
            tor_verified=True, all_raw_packets_on_verified_tor_guard_sockets=True,
            final_domain_matches_label=True, drop_count=0, title=meta.get('title'),
            body_chars=meta.get('content_health', {}).get('body_chars'),
            guard_connections=len(connections), window_seconds=meta['window_seconds']))
        details[-1]['tls_application_data_frames'] = len(tls_result.stdout.splitlines())
    counts = Counter(row['domain'] for row in successful_rows(rows))
    referenced_raw = set()
    for row in rows:
        sidecar = safe_path(root, row['trace_file']).with_suffix('.json')
        if sidecar.exists():
            raw_file = json.loads(sidecar.read_text(encoding='utf-8')).get('raw_file')
            if raw_file:
                referenced_raw.add(raw_file)
    unfinalized = [dict(raw_file=p.relative_to(root).as_posix(), bytes=p.stat().st_size,
                       sha256=digest(p), status='unfinalized, excluded from labeled data')
                   for p in (root / 'raw').glob('*.pcapng') if p.relative_to(root).as_posix() not in referenced_raw]
    return dict(attempts=len(rows), successes=len(details), failures=len(rows) - len(details),
                successful_counts=dict(sorted(counts.items())), per_trace=details,
                failed_attempts=[row for row in rows if row['success'] != 'true'],
                unfinalized_raw_captures=unfinalized,
                pilot_passed=len(counts) >= 2 and min(counts.values(), default=0) >= 2,
                full_crawl_started=False, kfp_held_out_accuracy_available=False,
                limitation='Same-day pilot verifies collection, it cannot estimate later-day generalization.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent / 'pilot')
    args = parser.parse_args()
    root = args.root.resolve()
    report = review(root)
    (root / 'reports').mkdir(exist_ok=True)
    write_json(root / 'reports/pilot_validation.json', report)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
