"""Journal interrupted attempts as failures, retaining raw captures unchanged.

Only run after the collector has exited. A stale lock must first be checked and
removed by the operator. This command never promotes an interrupted trace.
"""
import argparse
import json
from pathlib import Path
from collect import dataset_lock
from common import MANIFEST_FIELDS, append_csv, digest, read_manifest, write_json


def recover(root):
    existing = {row['trace_file'] for row in read_manifest(root / 'manifest.csv')}
    recovered = []
    with dataset_lock(root):
        for sidecar in sorted((root / 'traces').glob('*.json')):
            meta = json.loads(sidecar.read_text(encoding='utf-8'))
            trace = sidecar.with_suffix('.trace')
            relative = trace.relative_to(root).as_posix()
            if relative in existing or meta.get('collection_state') != 'in_progress':
                continue
            raw = root / 'raw' / (meta['trace_id'] + '.pcapng')
            reason = 'Collector interrupted before attempt finalization, excluded from training'
            meta.update(success=False, collection_state='interrupted', errors=[reason],
                        raw_file=raw.relative_to(root).as_posix() if raw.exists() else None,
                        raw_sha256=digest(raw) if raw.exists() else None,
                        trace_sha256=digest(trace))
            write_json(sidecar, meta)
            append_csv(root / 'manifest.csv', MANIFEST_FIELDS, dict(trace_file=relative,
                domain=meta['domain'], requested_url=meta['requested_url'], final_url=meta.get('final_url', ''),
                collected_at=meta['collected_at'], load_type=meta['load_type'], success='false'))
            append_csv(root / 'failures.csv', ['trace_id', 'domain', 'attempted_at', 'load_type', 'error'],
                dict(trace_id=meta['trace_id'], domain=meta['domain'], attempted_at=meta['collected_at'],
                     load_type=meta['load_type'], error=reason))
            recovered.append(relative)
    return recovered


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent / 'pilot')
    args = parser.parse_args()
    print(json.dumps({'recovered_failures': recover(args.root.resolve())}, indent=2))
