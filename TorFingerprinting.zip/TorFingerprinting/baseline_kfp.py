"""k-FP: random forest leaf fingerprints, Hamming nearest neighbors, validation calibration."""
import argparse
import csv
import json
from pathlib import Path
import joblib
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, log_loss

from common import REPRESENTATION, digest, read_manifest, read_trace, safe_path, write_json
from kfp_features import FEATURE_VERSION, features
from prepare import audit, grouped_split


def make_features(root, rows):
    vectors = []
    for row in rows:
        if row['success'] != 'true':
            raise ValueError('Failure rows cannot enter the baseline')
        path = safe_path(root, row['trace_file'])
        meta = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
        if meta['trace_sha256'] != digest(path) or meta['representation'] != REPRESENTATION:
            raise ValueError(f'Trace hash/representation mismatch: {path}')
        vectors.append(features(*read_trace(path)))
    return np.stack(vectors)


def leaf_scores(query_leaves, train_leaves, train_y, classes, k, alpha=0.1):
    """Distance is fraction of trees whose terminal leaves differ."""
    if k < 1 or k > len(train_y):
        raise ValueError('k must be within training fingerprint count')
    result = np.empty((len(query_leaves), classes), dtype=np.float64)
    for i, query in enumerate(query_leaves):
        distances = np.mean(train_leaves != query, axis=1)
        # Stable sorting makes ties deterministic and independent of test labels.
        neighbors = np.argsort(distances, kind='stable')[:k]
        votes = np.bincount(train_y[neighbors], minlength=classes)
        result[i] = (votes + alpha) / (k + alpha * classes)
    return result


def calibrate(scores, temperature):
    logits = np.log(np.maximum(scores, 1e-15)) / temperature
    return np.exp(logits - logsumexp(logits, axis=1, keepdims=True))


def metrics(y, probabilities, labels):
    prediction = probabilities.argmax(axis=1)
    return dict(n=len(y), top1_accuracy=float(accuracy_score(y, prediction)),
                macro_f1=float(f1_score(y, prediction, labels=range(len(labels)), average='macro', zero_division=0)),
                negative_log_likelihood=float(log_loss(y, probabilities, labels=range(len(labels)))),
                labels=labels, confusion_matrix=confusion_matrix(y, prediction, labels=range(len(labels))).tolist())


def save_scores(path, rows, probabilities, labels):
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream)
        writer.writerow(['trace_file', 'domain', 'collected_at', 'load_type', 'predicted_domain'] + ['p:' + d for d in labels])
        for row, p in zip(rows, probabilities):
            writer.writerow([row['trace_file'], row['domain'], row['collected_at'], row['load_type'], labels[p.argmax()]] + p.tolist())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['extract', 'train', 'evaluate'])
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent / 'dataset')
    parser.add_argument('--trees', type=int, default=1000)
    parser.add_argument('--seed', type=int, default=614)
    args = parser.parse_args()
    root = args.root.resolve()
    details = audit(root)
    all_rows = [row for row, *_ in details]
    (root / 'reports').mkdir(exist_ok=True)
    if args.mode == 'extract':
        x = make_features(root, all_rows)
        np.savez_compressed(root / 'reports/kfp_features.npz', X=x,
            domains=np.array([r['domain'] for r in all_rows]),
            trace_files=np.array([r['trace_file'] for r in all_rows]),
            feature_version=np.array(FEATURE_VERSION), representation=np.array(REPRESENTATION))
        print(json.dumps(dict(shape=list(x.shape), feature_version=FEATURE_VERSION, evaluation_performed=False)))
        return
    expected, day_assignment = grouped_split(details)
    for name, rows in expected.items():
        if read_manifest(root / 'splits' / (name + '.csv')) != rows:
            raise ValueError('Split files are stale or altered. Run prepare.py again.')
    labels = sorted({r['domain'] for r in expected['train']})
    mapping = {label: i for i, label in enumerate(labels)}
    y = {name: np.array([mapping[r['domain']] for r in rows]) for name, rows in expected.items()}
    checkpoint = root / 'models/kfp.joblib'
    if args.mode == 'train':
        x = {name: make_features(root, expected[name]) for name in ['train', 'validation']}
        forest = RandomForestClassifier(n_estimators=args.trees, n_jobs=-1, random_state=args.seed)
        forest.fit(x['train'], y['train'])
        leaves = forest.apply(x['train']).astype(np.int32)
        validation_leaves = forest.apply(x['validation']).astype(np.int32)
        candidates = sorted({min(k, len(leaves)) for k in [1, 3, 5, 6, 10]})
        results = []
        for k in candidates:
            scores = leaf_scores(validation_leaves, leaves, y['train'], len(labels), k)
            result = minimize_scalar(lambda log_t: log_loss(y['validation'], calibrate(scores, np.exp(log_t)),
                                      labels=range(len(labels))), bounds=(-3, 3), method='bounded')
            temperature = float(np.exp(result.x))
            results.append(dict(k=k, temperature=temperature, validation_nll=float(result.fun)))
        selected = min(results, key=lambda result: (result['validation_nll'], result['k']))
        (root / 'models').mkdir(exist_ok=True)
        state = dict(forest=forest, training_leaves=leaves, training_y=y['train'], labels=labels,
            training_trace_files=[r['trace_file'] for r in expected['train']],
            training_class_prior=(np.bincount(y['train'], minlength=len(labels)) / len(y['train'])).tolist(),
            feature_version=FEATURE_VERSION, representation=REPRESENTATION, **selected,
            split_hashes={name: digest(root / 'splits' / (name + '.csv')) for name in expected},
            day_assignment=day_assignment, protocol='closed_world_kfp_hamming_knn', seed=args.seed)
        joblib.dump(state, checkpoint, compress=3)
        write_json(root / 'reports/kfp_validation_selection.json', results)
        write_json(root / 'reports/kfp_training.json', dict(labels=labels, train_size=len(leaves),
                   training_fingerprint_shape=list(leaves.shape), trees=args.trees, selected=selected,
                   held_out_test_evaluated=False))
        print(json.dumps(dict(checkpoint=str(checkpoint), training_leaves=list(leaves.shape), selected=selected)))
        return
    # Only load a checkpoint produced by this project from a trusted local run.
    state = joblib.load(checkpoint)
    if state['feature_version'] != FEATURE_VERSION or state['representation'] != REPRESENTATION or state['labels'] != labels:
        raise ValueError('Incompatible checkpoint schema or domain map')
    for name, value in state['split_hashes'].items():
        if value != digest(root / 'splits' / (name + '.csv')):
            raise ValueError('Dataset splits changed since training')
    for name in ['validation', 'test']:
        x = make_features(root, expected[name])
        leaves = state['forest'].apply(x).astype(np.int32)
        probabilities = calibrate(leaf_scores(leaves, state['training_leaves'], state['training_y'],
            len(labels), state['k']), state['temperature'])
        report = metrics(y[name], probabilities, labels)
        report.update(feature_version=FEATURE_VERSION, checkpoint_sha256=digest(checkpoint),
                      split_by='collection_day_America/New_York', calibrated_on='validation_only')
        write_json(root / 'reports' / ('kfp_' + name + '_metrics.json'), report)
        save_scores(root / 'reports' / ('kfp_' + name + '_scores.csv'), expected[name], probabilities, labels)
        print(name + ': ' + json.dumps(report))


if __name__ == '__main__':
    main()
