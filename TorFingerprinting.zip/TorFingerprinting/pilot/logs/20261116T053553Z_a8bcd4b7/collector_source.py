"""Collect and verify the client's own Tor-to-guard TCP packet traces."""
import argparse
import contextlib
import importlib.metadata
import ipaddress
import json
import os
import platform
import random
import re
import shutil
import signal
import socket
import subprocess
import sys
import time
import uuid
from collections import Counter
from pathlib import Path

from common import (MANIFEST_FIELDS, REPRESENTATION, append_csv, decode_tshark, digest,
                    label_matches, make_bpf, read_domains, read_manifest,
                    successful_rows, utc_now, write_json)


@contextlib.contextmanager
def dataset_lock(root):
    path = root / '.collection.lock'
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    try:
        os.write(fd, f'{os.getpid()}\n'.encode())
        os.close(fd)
        yield
    finally:
        path.unlink(missing_ok=True)


def tor_sockets(pid):
    import psutil
    return {(c.laddr.ip, c.laddr.port, c.raddr.ip, c.raddr.port)
            for c in psutil.Process(pid).net_connections(kind='tcp')
            if c.status == psutil.CONN_ESTABLISHED and c.raddr
            and not ipaddress.ip_address(c.raddr.ip).is_loopback}


def guard_connections(controller, pid):
    """Match process sockets to consensus endpoints of built circuit first hops."""
    circuits, relays, endpoints = [], {}, set()
    for circuit in controller.get_circuits():
        if circuit.status != 'BUILT' or not circuit.path:
            continue
        fp = circuit.path[0][0]
        descriptor = controller.get_network_status(fp, None)
        if descriptor is None:
            continue
        addresses = {(descriptor.address, descriptor.or_port)}
        addresses.update((address, port) for address, port, _ in descriptor.or_addresses)
        endpoints.update(addresses)
        relays[fp] = dict(fingerprint=fp, nickname=descriptor.nickname, endpoints=sorted(addresses))
        circuits.append(dict(id=circuit.id, purpose=str(circuit.purpose),
                             path=[fingerprint for fingerprint, _ in circuit.path]))
    connections = {conn for conn in tor_sockets(pid) if (conn[2], conn[3]) in endpoints}
    if not connections:
        raise RuntimeError('No Tor process socket matches a built circuit first-hop relay')
    return connections, dict(first_hop_relays=list(relays.values()), built_circuits=circuits)


def reported_drops(text):
    counts = [int(n) for n in re.findall(r'Packets dropped:\s*(\d+)', text)]
    counts.extend(int(n) for n in re.findall(
        r"Packets received/dropped on interface [^\n]*?:\s*\d+/(\d+)", text))
    return max(counts, default=None)


def extract(pcap, connections, started_at, window):
    fields = ['frame.time_epoch', 'ip.src', 'ipv6.src', 'tcp.srcport',
              'ip.dst', 'ipv6.dst', 'tcp.dstport', 'tcp.len']
    command = ['tshark', '-n', '-r', str(pcap), '-Y', 'tcp.len > 0', '-T', 'fields',
               '-E', 'separator=/t', '-E', 'occurrence=f']
    for field in fields:
        command.extend(['-e', field])
    result = subprocess.run(command, check=True, capture_output=True, text=True, timeout=120)
    return [row for row in decode_tshark(result.stdout.splitlines(), connections, started_at)
            if row[0] <= window]


def wait_for(driver, predicate, timeout):
    deadline, last_error = time.monotonic() + timeout, None
    while time.monotonic() < deadline:
        try:
            result = predicate(driver)
            if result:
                return result
        except Exception as error:
            last_error = error
        time.sleep(0.25)
    raise RuntimeError(f'Browser condition timed out, last error: {last_error}')


def verify_tor(driver):
    driver.get('https://check.torproject.org/api/ip')

    def is_tor(browser):
        if 'check.torproject.org/api/ip' not in browser.current_url:
            return False
        value = json.loads(browser.execute_script("return document.body ? document.body.innerText : ''"))
        if value.get('IsTor') is not True:
            raise RuntimeError('Tor Project API did not report IsTor=true')
        return value

    result = wait_for(driver, is_tor, 60)
    driver.get('about:blank')
    wait_for(driver, lambda d: d.current_url == 'about:blank', 10)
    return dict(checked_at=utc_now(), endpoint='https://check.torproject.org/api/ip',
                is_tor=True, exit_ip=result.get('IP'))


def capture(driver, tor_pid, controller, target, pcap, log_path, args, meta):
    connections, guard_meta = guard_connections(controller, tor_pid)
    meta.update(guard_meta, tor_sockets=sorted(connections), capture_filter=make_bpf(connections))
    initial_external = tor_sockets(tor_pid)
    command = ['dumpcap', '-q', '-p', '-i', args.interface, '-f', meta['capture_filter'],
               '-s', '0', '-w', str(pcap)]
    packets, errors, opened = [], [], set()
    with log_path.open('w+', encoding='utf-8') as log:
        proc = subprocess.Popen(command, stdout=log, stderr=log)
        try:
            deadline = time.monotonic() + 15
            while time.monotonic() < deadline:
                log.seek(0)
                if 'Capturing on ' in log.read() and pcap.exists() and pcap.stat().st_size >= 48:
                    break
                if proc.poll() is not None:
                    raise RuntimeError('dumpcap failed before capture readiness')
                time.sleep(0.1)
            else:
                raise RuntimeError('dumpcap did not become ready')
            meta['capture_started_epoch'] = time.time()
            meta['collected_at'] = utc_now()
            deadline = time.monotonic() + args.window_seconds
            driver.get(target['url'])
            while time.monotonic() < deadline:
                if proc.poll() is not None:
                    raise RuntimeError('dumpcap exited during the page load')
                opened.update(tor_sockets(tor_pid) - initial_external)
                time.sleep(min(0.2, max(0, deadline - time.monotonic())))
            meta.update(final_url=driver.current_url, title=driver.title,
                        ready_state=driver.execute_script('return document.readyState'))
            driver.save_screenshot(str(log_path.with_suffix('.png')))
            meta['content_health'] = driver.execute_script("""return {
                body_chars: document.body ? document.body.innerText.length : 0,
                heading: document.querySelector('h1') ? document.querySelector('h1').innerText.slice(0,200) : '',
                navigation: performance.getEntriesByType('navigation').map(e => ({
                    name:e.name, duration:e.duration, responseStatus:e.responseStatus || null}))
            }""")
            final_connections, final_guard_meta = guard_connections(controller, tor_pid)
            meta['final_guard_state'] = final_guard_meta
            if final_connections - connections:
                errors.append('A new guard socket was absent from the capture filter')
        except Exception as error:
            errors.append(f'{type(error).__name__}: {error}')
        finally:
            if proc.poll() is None:
                proc.send_signal(signal.SIGINT)
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
                    errors.append('dumpcap required forced termination')
        if proc.returncode != 0:
            errors.append(f'dumpcap exit status {proc.returncode}')
        log.seek(0)
        drops = reported_drops(log.read())
        meta['reported_dropped_packets'] = drops
        if drops is None or drops > 0:
            errors.append(f'Capture drops could not be cleared: {drops}')
    if 'capture_started_epoch' in meta and pcap.exists():
        try:
            packets = extract(pcap, connections, meta['capture_started_epoch'], args.window_seconds)
        except Exception as error:
            errors.append(f'Packet extraction failed: {error}')
    meta['new_external_sockets_observed'] = sorted(opened)
    if opened:
        errors.append('Tor opened new external sockets during the capture window')
    meta['final_domain_matches_label'] = label_matches(target['domain'], meta.get('final_url', ''))
    meta['redirected'] = meta.get('final_url', '') != target['url']
    if not meta['final_domain_matches_label']:
        errors.append('Final URL domain does not match requested domain label')
    if meta.get('ready_state') != 'complete':
        errors.append('Page did not complete within the fixed observation window')
    title = meta.get('title', '').lower()
    if any(word in title for word in ['access denied', 'just a moment', 'captcha', 'robot check', 'verify you are human']):
        errors.append('Page title indicates an access challenge')
    if len(packets) < args.min_packets or {row[1] for row in packets} != {-1, 1}:
        errors.append(f'Insufficient bidirectional TCP payload packets: {len(packets)}')
    meta['errors'] = errors
    return packets


def preflight(args):
    if sys.platform != 'linux':
        raise RuntimeError('Run this collector with the configured Ubuntu WSL2 environment')
    for name in ['dumpcap', 'tshark', 'geckodriver']:
        if not shutil.which(name):
            raise RuntimeError(f'Missing executable {name}')
    for package in ['tbselenium', 'stem', 'psutil', 'selenium']:
        importlib.metadata.version(package)
    if not (args.tbb / 'Browser/firefox').is_file() or not args.tor_binary.is_file():
        raise RuntimeError('Invalid Tor Browser path')
    if args.socks_port == args.control_port:
        raise ValueError('SOCKS and control ports must differ')
    for port in [args.socks_port, args.control_port]:
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', port))
    subprocess.run(['dumpcap', '-D'], check=True, capture_output=True, timeout=15)


def collect(args, domains):
    from selenium.webdriver.firefox.options import Options
    from stem.control import Controller
    from stem.process import launch_tor_with_config
    from tbselenium.tbdriver import TorBrowserDriver
    import tbselenium.common as cm

    root = args.root
    run_id = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()) + '_' + uuid.uuid4().hex[:8]
    run_dir = root / 'logs' / run_id
    run_dir.mkdir(parents=True)
    shutil.copy2(Path(__file__), run_dir / 'collector_source.py')
    shutil.copy2(Path(__file__).with_name('common.py'), run_dir / 'common_source.py')
    counts = Counter((r['domain'], r['load_type']) for r in successful_rows(read_manifest(root / 'manifest.csv')))
    rng, tasks = random.Random(args.seed), []
    for round_number in range(args.batch_per_pair):
        block = [(domain, kind) for domain in domains for kind in args.load_types
                 if counts[(domain['domain'], kind)] + round_number < args.repeats]
        rng.shuffle(block)
        tasks.extend(block)
    if not tasks:
        print('Requested successful sample counts already satisfied.')
        return
    versions = {name: importlib.metadata.version(name) for name in ['tbselenium', 'selenium', 'stem', 'psutil']}
    versions.update(python=sys.version, platform=platform.platform(), collector_sha256=digest(Path(__file__)))
    for name, command in [('browser', [str(args.tbb / 'Browser/firefox'), '--version']),
                          ('tor', [str(args.tor_binary), '--version']), ('geckodriver', ['geckodriver', '--version']),
                          ('dumpcap', ['dumpcap', '--version'])]:
        versions[name] = subprocess.run(command, capture_output=True, text=True, timeout=20).stdout.strip()
    write_json(run_dir / 'run.json', dict(run_id=run_id, started_at=utc_now(), versions=versions,
        arguments={k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
        domains=domains, representation=REPRESENTATION, planned_attempts=len(tasks)))
    saved_cwd, saved_env = Path.cwd(), os.environ.copy()
    args.tor_data.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.environ['LD_LIBRARY_PATH'] = str(args.tor_binary.parent) + (':' + saved_env['LD_LIBRARY_PATH'] if saved_env.get('LD_LIBRARY_PATH') else '')
    try:
        tor = launch_tor_with_config(tor_cmd=str(args.tor_binary), timeout=180,
            init_msg_handler=lambda line: print(line, flush=True), config={
            'DataDirectory': str(args.tor_data), 'SocksPort': f'127.0.0.1:{args.socks_port}',
            'ControlPort': f'127.0.0.1:{args.control_port}', 'CookieAuthentication': '1',
            'ClientOnly': '1', 'AvoidDiskWrites': '1',
            'Log': ['notice stdout', f'notice file {run_dir / "tor.log"}']})
    finally:
        os.environ.clear()
        os.environ.update(saved_env)
    succeeded = 0
    try:
        with Controller.from_port(address='127.0.0.1', port=args.control_port) as controller:
            controller.authenticate()
            for index, (target, load_type) in enumerate(tasks, 1):
                trace_id = run_id + '_' + uuid.uuid4().hex[:12]
                trace, pcap = root / 'traces' / (trace_id + '.trace'), root / 'raw' / (trace_id + '.pcapng')
                driver, packets = None, []
                meta = dict(trace_id=trace_id, run_id=run_id, domain=target['domain'],
                    requested_url=target['url'], final_url='', collected_at=utc_now(),
                    load_type=load_type, representation=REPRESENTATION, phase=args.phase,
                    window_seconds=args.window_seconds, errors=[],
                    load_definition='fresh_template_profile' if load_type == 'cold' else 'same_url_after_one_uncaptured_prime',
                    defense='stock_tor_no_added_wf_defense')
                try:
                    options = Options()
                    options.binary_location = str(args.tbb / 'Browser/firefox')
                    options.page_load_strategy = 'none'
                    driver = TorBrowserDriver(str(args.tbb), tor_cfg=cm.USE_STEM,
                        executable_path=shutil.which('geckodriver'), socks_port=args.socks_port,
                        control_port=args.control_port, headless=True, options=options,
                        tbb_logfile_path=str(run_dir / (trace_id + '.browser.log')),
                        pref_dict={'network.proxy.type': 1, 'network.proxy.socks': '127.0.0.1',
                                   'network.proxy.socks_remote_dns': True, 'network.proxy.failover_direct': False,
                                   'devtools.jsonview.enabled': False})
                    driver.set_page_load_timeout(20)
                    driver.set_script_timeout(10)
                    meta['tor_verification'] = verify_tor(driver)
                    if load_type == 'warm':
                        driver.get(target['url'])
                        wait_for(driver, lambda d: label_matches(target['domain'], d.current_url) and
                                 d.execute_script('return document.readyState') == 'complete', args.window_seconds)
                        time.sleep(5)
                    time.sleep(args.pre_capture_seconds)
                    packets = capture(driver, tor.pid, controller, target, pcap,
                                      run_dir / (trace_id + '.capture.log'), args, meta)
                except Exception as error:
                    meta['errors'].append(f'{type(error).__name__}: {error}')
                    if driver is not None:
                        with contextlib.suppress(Exception):
                            meta['final_url'] = driver.current_url
                            meta['title'] = driver.title
                            driver.save_screenshot(str(run_dir / (trace_id + '.failed.png')))
                            meta['failure_body_excerpt'] = driver.execute_script("return document.body ? document.body.innerText.slice(0,1000) : ''")
                finally:
                    if driver is not None:
                        with contextlib.suppress(Exception):
                            driver.quit()
                    os.chdir(saved_cwd)
                    os.environ.clear()
                    os.environ.update(saved_env)
                meta['success'] = not meta['errors']
                with trace.open('x', encoding='utf-8', newline='\n') as stream:
                    stream.write('# seconds_since_navigation\tdirection\ttcp_payload_bytes\n')
                    for elapsed, direction, length in packets:
                        stream.write(f'{elapsed:.6f}\t{direction}\t{length}\n')
                meta.update(packet_count=len(packets), trace_sha256=digest(trace),
                            raw_file=pcap.relative_to(root).as_posix() if pcap.exists() else None,
                            raw_sha256=digest(pcap) if pcap.exists() else None)
                write_json(trace.with_suffix('.json'), meta)
                append_csv(root / 'manifest.csv', MANIFEST_FIELDS, dict(
                    trace_file=trace.relative_to(root).as_posix(), domain=target['domain'],
                    requested_url=target['url'], final_url=meta['final_url'], collected_at=meta['collected_at'],
                    load_type=load_type, success=str(meta['success']).lower()))
                if meta['success']:
                    succeeded += 1
                else:
                    append_csv(root / 'failures.csv', ['trace_id', 'domain', 'attempted_at', 'load_type', 'error'],
                               dict(trace_id=trace_id, domain=target['domain'], attempted_at=meta['collected_at'],
                                    load_type=load_type, error=' | '.join(meta['errors'])))
                print(f'[{index}/{len(tasks)}] {"OK" if meta["success"] else "FAILED"} {target["domain"]} '
                      f'{load_type}, packets={len(packets)}, final={meta["final_url"]}, errors={meta["errors"]}', flush=True)
                if index < len(tasks):
                    time.sleep(args.pause_seconds + rng.uniform(0, args.jitter_seconds))
    finally:
        tor.terminate()
        try:
            tor.wait(timeout=15)
        except subprocess.TimeoutExpired:
            tor.kill()
            tor.wait()
        os.chdir(saved_cwd)
        os.environ.clear()
        os.environ.update(saved_env)
    print(f'Batch complete: {succeeded}/{len(tasks)} successful, manifest={root / "manifest.csv"}', flush=True)


def main():
    project = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=['pilot', 'full'], default='pilot')
    parser.add_argument('--root', type=Path)
    parser.add_argument('--domains', type=Path)
    parser.add_argument('--tbb', type=Path, default=Path('/home/eric/tor-fingerprinting-runtime/tor-browser'))
    parser.add_argument('--tor-binary', type=Path)
    parser.add_argument('--tor-data', type=Path)
    parser.add_argument('--interface', default='eth0')
    parser.add_argument('--socks-port', type=int, default=9250)
    parser.add_argument('--control-port', type=int, default=9251)
    parser.add_argument('--repeats', type=int, default=2)
    parser.add_argument('--batch-per-pair', type=int, default=2)
    parser.add_argument('--load-types', nargs='+', choices=['cold', 'warm'], default=['cold'])
    parser.add_argument('--window-seconds', type=float, default=45)
    parser.add_argument('--pre-capture-seconds', type=float, default=5)
    parser.add_argument('--pause-seconds', type=float, default=15)
    parser.add_argument('--jitter-seconds', type=float, default=5)
    parser.add_argument('--min-packets', type=int, default=20)
    parser.add_argument('--seed', type=int, default=614)
    parser.add_argument('--plan', action='store_true')
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    args.root = (args.root or project / ('pilot' if args.phase == 'pilot' else 'dataset')).resolve()
    args.domains = (args.domains or project / 'config' / ('pilot_domains.csv' if args.phase == 'pilot' else 'domains.csv')).resolve()
    args.tbb = args.tbb.resolve()
    args.tor_binary = (args.tor_binary or args.tbb / 'Browser/TorBrowser/Tor/tor').resolve()
    args.tor_data = (args.tor_data or Path('/home/eric/tor-fingerprinting-runtime/private') / args.phase).resolve()
    if min(args.repeats, args.batch_per_pair, args.min_packets, args.window_seconds) <= 0:
        parser.error('Counts and capture window must be positive')
    if min(args.pre_capture_seconds, args.pause_seconds, args.jitter_seconds) < 0:
        parser.error('Wait times cannot be negative')
    args.load_types = list(dict.fromkeys(args.load_types))
    domains = read_domains(args.domains)
    if args.phase == 'pilot' and (len(domains) > 3 or args.batch_per_pair > 3):
        parser.error('Pilot is limited to 3 domains and 3 attempts per pair per batch')
    if args.plan:
        print(json.dumps(dict(domains=domains, root=str(args.root), phase=args.phase,
            load_types=args.load_types, total_success_target=len(domains) * len(args.load_types) * args.repeats,
            attempts_per_pair_this_batch=args.batch_per_pair), indent=2))
        return
    preflight(args)
    if args.check:
        print('Dependency checks passed. A live pilot must verify browsing and capture.')
        return
    for folder in ['traces', 'raw', 'logs', 'models', 'splits', 'reports']:
        (args.root / folder).mkdir(parents=True, exist_ok=True)
    manifest = args.root / 'manifest.csv'
    if not manifest.exists():
        manifest.write_text(','.join(MANIFEST_FIELDS) + '\n', encoding='utf-8')
    with dataset_lock(args.root):
        collect(args, domains)


if __name__ == '__main__':
    main()
